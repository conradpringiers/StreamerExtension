console.log('')
console.log('🔥 Just a console log to say that the extension started.')
console.log('❗ Envie de nous aider ? http://guilded.alzhia.eu/ !')
console.log('')